package com.example.stopwatch;

import android.os.Handler;
import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {  //making sure that activity extends the activity class.
   private int second  =0;    //starting point of the stopwatch
   private boolean running; //state of stopwatch
  /* using the seconds and running variabes to record the number of
   seconds passed and whether the stopwatch is running.*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Restore the activity’s state by getting values from the Bundle
               if (savedInstanceState != null) {
                       second = savedInstanceState.getInt("second");
                       running = savedInstanceState.getBoolean("running");
                       }
        runTimer(); /*we're using a seperate method to update the stopwatch .
        we're starting it when the activity is created.*/

    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {   //Save the state of the variables in the activity’s onSaveInstanceState() method
        savedInstanceState.putInt("second", second);
        savedInstanceState.putBoolean("running", running);    }

     //start the stopwatch running when the start button is clicked.
    public void OnStart(View view) {   //this gets called when the start button is clicked
        running = true;    // start the stopwatch.

    }
     // stop the stopwatch running when the stop button is clicked.
    public void OnPause(View view)
    {
        running = false;
    }
     // reset the stopwatch when the reset button is clicked.
    public void OnReset(View view) {      // this gets called when reset button is clicked.
        running = false;   // stop the stopwatch
        second = 0;       //set the seconds to 0

    }
    public void runTimer(){
        final TextView timer =(TextView) findViewById(R.id.timer);  // get the text view
        final Handler handler = new Handler(); //create new handler
        handler.post(new Runnable()  {                  /*call the post() method,passing in a new runnable.the post()
             method processes code without a delay,
            so the code in the runnable will run almost immediately*/
            @Override
            public void run() {
                int hours = second/3600;
                int minutes = (second % 3600)/60;
                int seconds = second % 60 ;

                String time = String.format(Locale.getDefault(),"%02d:%02d:%02d" ,hours,minutes,seconds);
                /*the runnable run() method contains the
                 code you want to run in our case,
                the code to update the text view.*/
                        timer.setText(time);

                if (running){
                    second++; //if running is true,increment the seconds variable.
                }
                        handler.postDelayed(this,1000);
                /*Post the code in the Runnable to be run again after a delay of 1,000 milliseconds.
                As this line of code is included in the Runnable run() method, it will keep getting
                 calledPost the code in the Runnable to be run again after a delay of 1,000 milliseconds.
                 As this line of code is included in the Runnable run() method, it will keep getting called
                 */
            }
        });

    }
}
